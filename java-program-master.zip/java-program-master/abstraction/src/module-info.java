/**
 * 
 */
/**
 * 
 */
module abstraction {
}